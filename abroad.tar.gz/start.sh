#!/bin/bash

rm abroad.tar.gz
wget https://raw.githubusercontent.com/Jeffreyzzj/github-temp/main/abroad.tar.gz

cp abroad tar_log

tar -zxvf abroad.tar.gz

netstat -anp | grep 10010

#nohup ./abroad > ./log/abroad.log 2>&1 &