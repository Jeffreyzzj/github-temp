#!/bin/bash

#nohup ./abroad > ./log/abroad.log 2>&1 &